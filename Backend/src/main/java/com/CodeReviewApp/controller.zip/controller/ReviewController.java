package com.CodeReviewApp.controller;

import com.CodeReviewApp.model.CodeSubmission;
import com.CodeReviewApp.model.ReviewResult;
import com.CodeReviewApp.repository.SubmissionRepository;
import com.CodeReviewApp.repository.ReviewResultRepository;
import com.CodeReviewApp.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/review")
public class ReviewController {

    @Autowired 
    private ReviewService reviewService;
    
    @Autowired 
    private SubmissionRepository submissionRepo;
   
    @Autowired 
    private ReviewResultRepository reviewRepo;

    /* ---- 1. Trigger a fresh PMD review ---- */
    @PreAuthorize("hasRole('TESTER')")
    @PostMapping("/run/{submissionId}")
    public ReviewResult runReview(@PathVariable Long submissionId) {

        CodeSubmission sub = submissionRepo.findById(submissionId)
                            .orElseThrow(() -> new RuntimeException("Submission not found"));
        try {
            String lang = sub.getLanguage();
            if ("ZIP".equalsIgnoreCase(lang)) {
                return reviewService.analyzeZip(sub);
            } else {
                return reviewService.analyzeSnippet(sub);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error during review: " + e.getMessage());
        }           // returns new ReviewResult
    }
    
    @PreAuthorize("hasAnyRole('TESTER','DEVELOPER')")
    @GetMapping("/{id}")
    public ReviewResult getReviewById(@PathVariable Long id) {
        return reviewService.getReviewById(id);
    }
    
    @PreAuthorize("hasRole('TESTER')")
    @DeleteMapping("/deleteReviewResultById/{id}")
    public ResponseEntity<String> deleteReviewResultById(@PathVariable Long id) {
    	reviewService.deleteReviewResultById(id);
        return ResponseEntity.ok("Submission with ID " + id + " deleted successfully.");
    }
    
    @PreAuthorize("hasRole('TESTER')")
    @DeleteMapping("/deleteAllReviewResult/all")
    public ResponseEntity<String> deleteAllReviewResult() {
    	reviewService.deleteAllReviewResult();
        return ResponseEntity.ok("All submissions deleted successfully.");
    }
}
